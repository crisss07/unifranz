<!-- desde aqui login -->
<div style="margin-top:130px; margin-bottom:30px;">
	<?php echo $hola; ?>
</div>

<!-- fin login -->